package io.auric.qr;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.Result;
import com.google.zxing.RGBLuminanceSource;
import com.google.zxing.common.HybridBinarizer;
import com.journeyapps.barcodescanner.IntentIntegrator;
import com.journeyapps.barcodescanner.IntentResult;

import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

public final class MainActivity extends Activity {
  private static final int PICK_IMAGE=4001, SAVE_DOCUMENT=4002, OPEN_PROJECT=4003;
  private WebView webView;
  private String pendingSaveId=null,pendingSaveBytes=null,pendingOpenId=null;
  private WebViewAssetLoader loader;

  @Override public void onCreate(Bundle savedInstance){super.onCreate(savedInstance);
    loader=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
    webView=new WebView(this);webView.setBackgroundColor(0xff080a0e);webView.getSettings().setJavaScriptEnabled(true);webView.getSettings().setDomStorageEnabled(true);
    webView.getSettings().setAllowFileAccess(false);webView.getSettings().setAllowContentAccess(false);webView.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    webView.getSettings().setMediaPlaybackRequiresUserGesture(true);
    webView.addJavascriptInterface(new Bridge(),"AuricAndroid");
    webView.setWebViewClient(new WebViewClient(){
      @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){return loader.shouldInterceptRequest(request.getUrl());}
      @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return !r.getUrl().toString().startsWith("https://appassets.androidplatform.net/assets/");}
    });
    webView.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onJsConfirm(WebView view,String url,String message,JsResult result){new AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("Aceptar",(d,w)->result.confirm()).setNegativeButton("Cancelar",(d,w)->result.cancel()).setOnCancelListener(d->result.cancel()).show();return true;}
      @Override public boolean onJsAlert(WebView view,String url,String message,JsResult result){new AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("Aceptar",(d,w)->result.confirm()).show();return true;}
    });
    setContentView(webView);
    webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
  }

  private void js(String code){runOnUiThread(()->{if(webView!=null)webView.evaluateJavascript(code,null);});}
  private void resolve(String id,String json){js("window.__auricAndroidResolve("+JSONObject.quote(id)+","+json+");");}
  private void notifyScanner(String raw){js("window.AuricScanner&&window.AuricScanner.onNativeResult("+JSONObject.quote(raw==null?"":raw)+");");}
  private String jsonError(String value){return "{\"error\":"+JSONObject.quote(value)+"}";}
  public final class Bridge {
    @JavascriptInterface public void scanCamera(){runOnUiThread(()->new IntentIntegrator(MainActivity.this).setCaptureActivity(ScanActivity.class).setDesiredBarcodeFormats(IntentIntegrator.QR_CODE).setPrompt("Escanea un código QR").setBeepEnabled(false).setOrientationLocked(true).initiateScan());}
    @JavascriptInterface public void scanImage(){runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_IMAGE);});}
    @JavascriptInterface public void shareText(String t){runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,t);startActivity(Intent.createChooser(i,"Compartir código QR"));});}
    @JavascriptInterface public void openLink(String s){runOnUiThread(()->{try{Uri u=Uri.parse(s);if(!"https".equals(u.getScheme())&&!"http".equals(u.getScheme()))return;if(u.getHost()==null)return;startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}});}
    @JavascriptInterface public void saveFile(String id,String filename,String base64){runOnUiThread(()->{try{
      if(base64.length()>42_000_000){resolve(id,jsonError("El archivo supera 30 MB."));return;}
      pendingSaveId=id;pendingSaveBytes=base64;
      Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType(mime(filename));i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_TITLE,filename);
      startActivityForResult(i,SAVE_DOCUMENT);
    }catch(Exception e){resolve(id,jsonError("No se pudo abrir el guardado."));}});}
    @JavascriptInterface public void openProject(String id){runOnUiThread(()->{pendingOpenId=id;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,OPEN_PROJECT);});}
  }
  private static String mime(String f){String x=f.toLowerCase();if(x.endsWith(".png"))return "image/png";if(x.endsWith(".svg"))return "image/svg+xml";if(x.endsWith(".jpg"))return "image/jpeg";if(x.endsWith(".webp"))return "image/webp";if(x.endsWith(".pdf"))return "application/pdf";if(x.endsWith(".zip"))return "application/zip";return "application/octet-stream";}
  @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);
    if(req==PICK_IMAGE){if(res!=RESULT_OK||data==null){notifyScanner(null);return;}
      new Thread(()->{String value=null;try{value=decodeImage(data.getData());}catch(Exception ignored){}notifyScanner(value);}).start();return;}
    if(req==SAVE_DOCUMENT){String id=pendingSaveId, b64=pendingSaveBytes;pendingSaveId=null;pendingSaveBytes=null;if(id==null)return;
      if(res!=RESULT_OK||data==null){resolve(id,"{\"canceled\":true}");return;}
      new Thread(()->{try(OutputStream out=getContentResolver().openOutputStream(data.getData())){if(out==null)throw new Exception("No se puede escribir el archivo");out.write(Base64.decode(b64,Base64.DEFAULT));out.flush();resolve(id,"{\"ok\":true}");}catch(Exception e){resolve(id,jsonError("No se pudo guardar el archivo."));}}).start();return;}
    if(req==OPEN_PROJECT){String id=pendingOpenId;pendingOpenId=null;if(id==null)return;if(res!=RESULT_OK||data==null){resolve(id,"{\"canceled\":true}");return;}
      new Thread(()->{try(InputStream in=getContentResolver().openInputStream(data.getData())){if(in==null)throw new Exception("No se puede abrir");ByteArrayOutputStream buf=new ByteArrayOutputStream();byte[] block=new byte[8192];int n;while((n=in.read(block))!=-1){buf.write(block,0,n);if(buf.size()>12*1024*1024)throw new Exception("Proyecto demasiado grande");}String content=buf.toString("UTF-8");resolve(id,"{\"text\":"+JSONObject.quote(content)+"}");}catch(Exception e){resolve(id,jsonError("No se pudo leer el proyecto."));}}).start();return;}
    IntentResult result=IntentIntegrator.parseActivityResult(req,res,data);if(result!=null)notifyScanner(result.getContents());
  }
  private String decodeImage(Uri uri)throws Exception{
    BitmapFactory.Options opt=new BitmapFactory.Options();opt.inJustDecodeBounds=true;
    try(InputStream i=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(i,null,opt);}
    int factor=1;while(opt.outWidth/factor>1600||opt.outHeight/factor>1600)factor*=2;
    opt.inJustDecodeBounds=false;opt.inSampleSize=factor;
    Bitmap bitmap;try(InputStream i=getContentResolver().openInputStream(uri)){bitmap=BitmapFactory.decodeStream(i,null,opt);}
    if(bitmap==null)throw new Exception("Imagen no válida");
    try {int width=bitmap.getWidth(),height=bitmap.getHeight();int[] pixels=new int[width*height];bitmap.getPixels(pixels,0,width,0,0,width,height);
      BinaryBitmap b=new BinaryBitmap(new HybridBinarizer(new RGBLuminanceSource(width,height,pixels)));
      MultiFormatReader reader=new MultiFormatReader();reader.setHints(Collections.singletonMap(DecodeHintType.POSSIBLE_FORMATS,Collections.singletonList(com.google.zxing.BarcodeFormat.QR_CODE)));
      Result result=reader.decodeWithState(b);return result.getText();
    }finally{bitmap.recycle();}
  }
  @Override protected void onDestroy(){if(webView!=null){webView.destroy();webView=null;}super.onDestroy();}
}
