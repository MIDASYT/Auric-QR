package io.auric.qr;
import com.journeyapps.barcodescanner.CaptureActivity;
/** Captura nativa en formato vertical. */
public class ScanActivity extends CaptureActivity {}
