/* Auric QR 1.0.0 — QR estáticos, generación y exportación completamente local. */
(() => {
'use strict';
const $ = (q, root=document) => root.querySelector(q);
const $$ = (q, root=document) => [...root.querySelectorAll(q)];
const icon = n => `<svg class="icon"><use href="#i-${n}"/></svg>`;
const clone = value => JSON.parse(JSON.stringify(value));
const safe = text => String(text ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
const hex = v => /^#[\da-f]{6}$/i.test(String(v||'')) ? v : '#101D35';
const limit = (n,min,max,fallback=min) => { const v=Number(n);return Number.isFinite(v)?Math.max(min,Math.min(max,v)):fallback; };
const formatNum = n => new Intl.NumberFormat('es-CL').format(n);
const DEFAULT = {
  type:'url', fields:{url:'https://example.com',text:'¡Hola desde Auric QR!',ssid:'Mi Wi-Fi',password:'',security:'WPA',hidden:false,first:'',last:'',organization:'',job:'',contactPhone:'',contactEmail:'',website:'',emailTo:'',emailSubject:'',emailBody:'',phone:'',smsPhone:'',smsText:'',waPhone:'',waText:'',latitude:'-33.4489',longitude:'-70.6693',eventTitle:'',eventLocation:'',eventStart:'',eventEnd:'',eventDescription:''},
  design:{dot:'square',colorMode:'solid',fg:'#101D35',fg2:'#6366F1',angle:45,bg:'#FFFFFF',transparent:false,eyeShape:'square',eyeInner:'square',eyeColor:'#101D35',eyeInnerColor:'#101D35',ecc:'H',margin:4},
  logo:{src:'',name:'',size:19,padding:12,shape:'rounded'},
  frame:{type:'none',text:'ESCANÉAME',color:'#111D34',textColor:'#FFFFFF'},
  export:{format:'png',width:1024,pdfMm:100,filename:'auric-qr'}
};
const inputDefs={
 url:[['url','URL de destino','url','https://tusitio.com','El QR contendrá directamente esta dirección.']],
 text:[['text','Texto del código','textarea','Escribe cualquier texto...','El contenido será visible al escanearlo.']],
 wifi:[['ssid','Nombre de la red (SSID)','text','Mi Wi-Fi'],['password','Contraseña de Wi-Fi','text','Contraseña'],['security','Seguridad','select',[['WPA','WPA / WPA2 / WPA3'],['WEP','WEP'],['nopass','Sin contraseña']]],['hidden','Red oculta','check']],
 vcard:[['first','Nombre','text','Nombre'],['last','Apellido','text','Apellido'],['organization','Empresa u organización','text','Opcional'],['job','Cargo','text','Opcional'],['contactPhone','Teléfono','tel','+56 9 ...'],['contactEmail','Correo electrónico','email','contacto@ejemplo.com'],['website','Sitio web','url','https://...']],
 email:[['emailTo','Destinatario','email','hola@ejemplo.com'],['emailSubject','Asunto','text','Asunto del correo'],['emailBody','Mensaje','textarea','Escribe un mensaje opcional...']],
 phone:[['phone','Número telefónico','tel','+56912345678']],
 sms:[['smsPhone','Número de destino','tel','+56912345678'],['smsText','Mensaje predeterminado','textarea','Escribe el texto...']],
 whatsapp:[['waPhone','Número con código de país','tel','56912345678','Sin +, espacios ni guiones.'],['waText','Mensaje inicial','textarea','Hola, quería consultar...']],
 geo:[['latitude','Latitud','text','-33.4489'],['longitude','Longitud','text','-70.6693','Se guarda el esquema geo:, no un acortador de enlaces.']],
 event:[['eventTitle','Nombre del evento','text','Mi evento'],['eventStart','Fecha y hora de inicio','datetime-local',''],['eventEnd','Fecha y hora de término','datetime-local',''],['eventLocation','Lugar','text','Opcional'],['eventDescription','Descripción','textarea','Opcional']]
};
const typeLabels={url:'Enlace web',text:'Texto libre',wifi:'Red Wi-Fi',vcard:'Contacto vCard',email:'Correo electrónico',phone:'Llamada',sms:'Mensaje SMS',whatsapp:'WhatsApp',geo:'Ubicación',event:'Evento'};
const names={content:'CONTENIDO',design:'DISEÑO',logo:'LOGOTIPO',frame:'MARCO',export:'EXPORTAR'};
const LS_LAST='auricqr-last-v1';const LS_HISTORY='auricqr-collection-v1';
function stateNormalize(x){ const s=clone(DEFAULT);if(!x||typeof x!=='object')return s;for(const k of ['fields','design','logo','frame','export']){if(x[k]&&typeof x[k]==='object')Object.assign(s[k],x[k]);}if(typeLabels[x.type])s.type=x.type;if(s.logo.src&&(typeof s.logo.src!=='string'||!/^data:image\/png;base64,[a-z0-9+/=]+$/i.test(s.logo.src)||s.logo.src.length>9*1024*1024)){s.logo.src='';s.logo.name='';}return s;}
function getLocal(key,fallback){try {return JSON.parse(localStorage.getItem(key)) ?? fallback;}catch{return fallback;}}
let state=stateNormalize(getLocal(LS_LAST,null));
function applyState(data){const next=stateNormalize(data);state.type=next.type;for(const k of ['fields','design','logo','frame','export']){Object.keys(state[k]).forEach(key=>delete state[k][key]);Object.assign(state[k],next[k]);}}
let history=getLocal(LS_HISTORY,[]);if(!Array.isArray(history))history=[];
let page='editor',tab='content',previewSVG='',lastPayload='',lastQr=null,previewURL='',renderTimer,renderTicket=0,verified=false,projectDirty=false;
const toast=(message,bad=false) => {const host=$('#toasts');const el=document.createElement('div');el.className='toast'+(bad?' error':'');el.innerHTML=icon(bad?'alert':'check')+`<span>${safe(message)}</span>`;host.appendChild(el);setTimeout(()=>el.remove(),4600);};
function cleanName(input){return (String(input||'auric-qr').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^\w\- ]+/g,'').trim().replace(/\s+/g,'-').slice(0,78)||'auric-qr');}
function fileInfo(){const w=limit(state.export.width,128,8192,1024);const h=Math.round(w*(state.frame.type==='none'?1000:1180)/1000);return {width:w,height:h};}
function saveAuto(){try{localStorage.setItem(LS_LAST,JSON.stringify(state));}catch{/* El proyecto sigue disponible para guardar en archivo. */}}
function displayField([key,label,kind,placeholder,note]){
 const val=state.fields[key];let inp='';
 if(kind==='textarea')inp=`<textarea data-field="${key}" placeholder="${safe(placeholder)}" rows="4">${safe(val)}</textarea>`;
 else if(kind==='select')inp=`<select data-field="${key}">${placeholder.map(([id,text])=>`<option value="${id}" ${val===id?'selected':''}>${safe(text)}</option>`).join('')}</select>`;
 else if(kind==='check')return `<div class="field"><label class="checkrow"><input data-field="${key}" type="checkbox" ${val?'checked':''}> ${safe(label)}</label></div>`;
 else inp=`<input data-field="${key}" type="${kind}" value="${safe(val)}" placeholder="${safe(placeholder)}" ${kind==='datetime-local'?'step="60"':''}/>`;
 return `<div class="field"><label for="fld-${key}">${safe(label)}</label>${inp}${note?`<small>${safe(note)}</small>`:''}</div>`;
}
function renderContent(){ $('#qr-type').value=state.type;$('#content-fields').innerHTML=inputDefs[state.type].map(displayField).join(''); }
function syncControls(){
 const d=state.design,l=state.logo,f=state.frame,e=state.export;
 const vals={'color-mode':d.colorMode,'gradient-angle':d.angle,'eye-shape':d.eyeShape,'eye-inner':d.eyeInner,'ecc':d.ecc,'margin':d.margin,'transparent':d.transparent,'logo-size':l.size,'logo-padding':l.padding,'logo-shape':l.shape,'frame-text':f.text,'export-size':e.width,'export-preset':[256,512,1024,2048,4096,8192].includes(Number(e.width))?String(e.width):'','pdf-mm':e.pdfMm,'filename':e.filename};
 for(const [id,val] of Object.entries(vals)){const node=$('#'+id);if(!node)continue;if(node.type==='checkbox')node.checked=!!val;else node.value=val;}
 for(const [colorId,textId,val] of [['color-fg','text-fg',d.fg],['color-fg2','text-fg2',d.fg2],['color-bg','text-bg',d.bg],['eye-color','text-eye',d.eyeColor],['eye-inner-color','text-eye-inner',d.eyeInnerColor],['frame-color','text-frame',f.color],['frame-text-color','text-frame-text',f.textColor]]){$('#'+colorId).value=hex(val);$('#'+textId).value=hex(val).toUpperCase();}
 $$('.shape').forEach(el=>el.classList.toggle('selected',el.dataset.dot===d.dot));$$('.frame-choice').forEach(el=>el.classList.toggle('active',el.dataset.frame===f.type));$$('.format-button').forEach(el=>el.classList.toggle('active',el.dataset.format===e.format));
 $('#gradient-color-field').classList.toggle('hidden',d.colorMode==='solid');$('#gradient-angle-field').classList.toggle('hidden',d.colorMode!=='linear');$('#gradient-angle-label').textContent=d.angle+'°';$('#margin-label').textContent=d.margin+' módulos';$('#logo-size-label').textContent=l.size+' %';$('#logo-padding-label').textContent=l.padding+' %';
 $('#logo-current').classList.toggle('hidden',!l.src);if(l.src){$('#logo-thumbnail').src=l.src;$('#logo-name').textContent=l.name;}$('#pdf-options').classList.toggle('hidden',e.format!=='pdf');$('#export-width-label').textContent=formatNum(e.width)+' px';const size=fileInfo();$('#measure-width').textContent=formatNum(size.width)+' px';$('#measure-height').textContent=formatNum(size.height)+' px';$('#measure-format').textContent=e.format.toUpperCase();
 renderContent();
}
function setTab(name){tab=name;$$('.tab').forEach(el=>{const active=el.dataset.tab===name;el.classList.toggle('active',active);el.setAttribute('aria-selected',String(active));});$$('.tab-panel').forEach(el=>el.classList.toggle('active',el.id==='panel-'+name));$('.control-scroll').scrollTop=0;}
function setView(name){page=name;$$('.view').forEach(el=>el.classList.toggle('active',el.id==='view-'+name));$$('.nav-btn').forEach(el=>el.classList.toggle('selected',el.dataset.view===name));$$('.header-actions').forEach(el=>el.classList.toggle('hidden',name!=='editor'));const config={editor:['EDITOR','Editor de códigos QR','Configura el contenido, el diseño y las opciones de exportación.'],collection:['COLECCIÓN','Tu biblioteca de diseños','Reutiliza los códigos que creaste en este dispositivo.'],batch:['LOTES','Generación por lotes','Exportación de múltiples códigos en un ZIP.'],about:['ACERCA DE','Acerca de Auric QR','Información de la aplicación.'],scanner:['ESCÁNER','Escanear códigos QR','Lectura mediante cámara o imagen, con historial local.']}[name];$('#breadcrumb').textContent=config[0];$('#page-title').textContent=config[1];$('#page-description').textContent=config[2];if(name==='collection')renderHistory();if(name==='batch')renderBatch();}
function escWiFi(x){return String(x||'').replace(/([\\;,:"])/g,'\\$1');}
function escCard(x){return String(x||'').replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/,/g,'\\,').replace(/;/g,'\\;');}
function payloadFor(s){
 const a=s.fields, v=k=>String(a[k]??'').trim();
 switch(s.type){
 case 'url':{let x=v('url');if(!x)throw Error('Escribe una dirección web.');if(!/^[a-z][\w+.-]*:\/\//i.test(x))x='https://'+x;let u;try{u=new URL(x);}catch{throw Error('La dirección web no es válida.');}if(!['http:','https:'].includes(u.protocol)||!u.hostname)throw Error('Usa una URL http o https válida.');return x;}
 case 'text':if(!v('text'))throw Error('Escribe el texto que debe contener el QR.');return String(a.text);
 case 'wifi':if(!v('ssid'))throw Error('Escribe el nombre de la red Wi-Fi.');return `WIFI:T:${v('security')};S:${escWiFi(a.ssid)};P:${v('security')==='nopass'?'':escWiFi(a.password)};H:${!!a.hidden};;`;
 case 'vcard':{if(!v('first')&&!v('last')&&!v('organization'))throw Error('Completa al menos un nombre u organización.');const data=['BEGIN:VCARD','VERSION:3.0',`N:${escCard(a.last)};${escCard(a.first)};;;`,`FN:${escCard([a.first,a.last].filter(Boolean).join(' ')||a.organization)}`];for(const [key,prefix] of [['organization','ORG:'],['job','TITLE:'],['contactPhone','TEL;TYPE=CELL:'],['contactEmail','EMAIL:'],['website','URL:']])if(v(key))data.push(prefix+escCard(a[key]));data.push('END:VCARD');return data.join('\r\n');}
 case 'email':{if(!v('emailTo')||!/^\S+@\S+\.\S+$/.test(v('emailTo')))throw Error('Escribe un correo electrónico válido.');const qs=new URLSearchParams();if(v('emailSubject'))qs.set('subject',a.emailSubject);if(v('emailBody'))qs.set('body',a.emailBody);return `mailto:${v('emailTo')}${qs.size?'?'+qs.toString():''}`;}
 case 'phone':if(!v('phone'))throw Error('Escribe un número telefónico.');return 'tel:'+v('phone');
 case 'sms':if(!v('smsPhone'))throw Error('Escribe un número de destino.');return `SMSTO:${v('smsPhone')}:${a.smsText||''}`;
 case 'whatsapp':{const num=v('waPhone').replace(/[^\d]/g,'');if(!num||num.length<7)throw Error('Escribe el número de WhatsApp con código de país.');return 'https://wa.me/'+num+(v('waText')?'?text='+encodeURIComponent(a.waText):'');}
 case 'geo':{const lat=Number(v('latitude')),lon=Number(v('longitude'));if(!v('latitude')||!v('longitude')||!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)throw Error('Indica coordenadas de latitud y longitud válidas.');return `geo:${lat},${lon}`;}
 case 'event':{if(!v('eventTitle')||!v('eventStart')||!v('eventEnd'))throw Error('Completa título, inicio y término del evento.');const start=new Date(a.eventStart),end=new Date(a.eventEnd);if(Number.isNaN(+start)||Number.isNaN(+end)||end<=start)throw Error('La fecha final debe ser posterior al inicio.');const fmt=date=>date.toISOString().replace(/[-:]/g,'').replace(/\.\d\d\d/,'');return ['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Auric QR//ES','BEGIN:VEVENT','UID:'+encodeURIComponent(a.eventTitle).slice(0,35)+'-'+start.getTime()+'@auricqr.local','DTSTAMP:'+fmt(new Date()),'DTSTART:'+fmt(start),'DTEND:'+fmt(end),'SUMMARY:'+escCard(a.eventTitle),...(v('eventLocation')?['LOCATION:'+escCard(a.eventLocation)]:[]),...(v('eventDescription')?['DESCRIPTION:'+escCard(a.eventDescription)]:[]),'END:VEVENT','END:VCALENDAR'].join('\r\n');}
 default:throw Error('Tipo de QR no reconocido.');
 }
}
function roundRectPath(x,y,w,h,r){r=Math.max(0,Math.min(r,w/2,h/2));if(!r)return `M${x},${y}h${w}v${h}h${-w}Z`;return `M${x+r},${y}H${x+w-r}Q${x+w},${y} ${x+w},${y+r}V${y+h-r}Q${x+w},${y+h} ${x+w-r},${y+h}H${x+r}Q${x},${y+h} ${x},${y+h-r}V${y+r}Q${x},${y} ${x+r},${y}Z`;}
function dotSVG(x,y,k,kind,fill){const s=v=>+v.toFixed(3),px=s(x),py=s(y);if(kind==='square')return `<rect x="${px}" y="${py}" width="${s(k)}" height="${s(k)}" fill="${fill}"/>`;if(kind==='dots')return `<circle cx="${s(x+k/2)}" cy="${s(y+k/2)}" r="${s(k*.42)}" fill="${fill}"/>`;if(kind==='diamond')return `<rect x="${s(x+k*.15)}" y="${s(y+k*.15)}" width="${s(k*.7)}" height="${s(k*.7)}" transform="rotate(45 ${s(x+k/2)} ${s(y+k/2)})" fill="${fill}"/>`;const inset=kind==='soft'?k*.07:k*.025,r=kind==='soft'?k*.24:k*.33;return `<rect x="${s(x+inset)}" y="${s(y+inset)}" width="${s(k-inset*2)}" height="${s(k-inset*2)}" rx="${s(r)}" fill="${fill}"/>`;}
function isEyeModule(x,y,n){return (x<7&&y<7)||(x>=n-7&&y<7)||(x<7&&y>=n-7);}
function qrSVG(s,payload,qr){
 const n=qr.getModuleCount(),d=s.design,l=s.logo,f=s.frame,frame=f.type!=='none',height=frame?1180:1000;
 const margin=limit(d.margin,0,10,4),k=1000/(n+2*margin),offset=margin*k;
 const fillPattern=d.colorMode==='solid'?hex(d.fg):'url(#auric-gradient)';
 const defs=[];
 if(d.colorMode==='linear'){const a=(Number(d.angle)||0)*Math.PI/180;const dx=Math.cos(a)*50,dy=Math.sin(a)*50;defs.push(`<linearGradient id="auric-gradient" x1="${50-dx}%" y1="${50-dy}%" x2="${50+dx}%" y2="${50+dy}%"><stop offset="0%" stop-color="${hex(d.fg)}"/><stop offset="100%" stop-color="${hex(d.fg2)}"/></linearGradient>`);}
 if(d.colorMode==='radial')defs.push(`<radialGradient id="auric-gradient"><stop offset="0%" stop-color="${hex(d.fg2)}"/><stop offset="100%" stop-color="${hex(d.fg)}"/></radialGradient>`);
 const lines=[`<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1000 ${height}" width="1000" height="${height}">`];
 let logoClip='';if(l.src){const side=1000*limit(l.size,8,28,19)/100;const pad=side*limit(l.padding,0,28,12)/100;const imgS=side-pad*2;const corner=l.shape==='circle'?imgS/2:l.shape==='rounded'?imgS*.15:0;logoClip=`<clipPath id="logo-clip"><rect x="${(1000-imgS)/2}" y="${(1000-imgS)/2}" width="${imgS}" height="${imgS}" rx="${corner}"/></clipPath>`;}
 if(defs.length||logoClip)lines.push(`<defs>${defs.join('')}${logoClip}</defs>`);
 if(!d.transparent)lines.push(`<rect width="1000" height="${height}" fill="${hex(d.bg)}"/>`);
 for(let y=0;y<n;y++){
   for(let x=0;x<n;x++){
     if(!qr.isDark(y,x)||isEyeModule(x,y,n))continue;
     const xx=offset+x*k,yy=offset+y*k;
     if(d.dot==='connected'){
       let run=1;while(x+run<n&&qr.isDark(y,x+run)&&!isEyeModule(x+run,y,n))run++;
       lines.push(`<rect x="${xx.toFixed(3)}" y="${(yy+k*.065).toFixed(3)}" width="${(k*run).toFixed(3)}" height="${(k*.87).toFixed(3)}" rx="${(k*.28).toFixed(3)}" fill="${fillPattern}"/>`);x+=run-1;
     }else lines.push(dotSVG(xx,yy,k,d.dot,fillPattern));
   }
 }
 const eyeO=hex(d.eyeColor),eyeI=hex(d.eyeInnerColor);
 for(const [ex,ey] of [[0,0],[n-7,0],[0,n-7]]){
   const x=offset+ex*k,y=offset+ey*k,outer=d.eyeShape;
   const outerRadius=outer==='square'?0:outer==='circle'?3.5*k:1.3*k;
   const innerCutRadius=outer==='square'?0:outer==='circle'?2.5*k:.8*k;
   lines.push(`<path d="${roundRectPath(x,y,7*k,7*k,outerRadius)}${roundRectPath(x+k,y+k,5*k,5*k,innerCutRadius)}" fill="${eyeO}" fill-rule="evenodd"/>`);
   const ix=x+2*k,iy=y+2*k,innerRadius=d.eyeInner==='square'?0:d.eyeInner==='circle'?1.5*k:.7*k;
   lines.push(`<path d="${roundRectPath(ix,iy,3*k,3*k,innerRadius)}" fill="${eyeI}"/>`);
 }
 if(l.src){const side=1000*limit(l.size,8,28,19)/100,pad=side*limit(l.padding,0,28,12)/100,srcX=(1000-side)/2,imgSide=side-2*pad;
   lines.push(`<rect x="${srcX}" y="${srcX}" width="${side}" height="${side}" rx="${l.shape==='circle'?side/2:l.shape==='rounded'?side*.15:0}" fill="${hex(d.bg)}"/>`);
   lines.push(`<image x="${srcX+pad}" y="${srcX+pad}" width="${imgSide}" height="${imgSide}" preserveAspectRatio="xMidYMid meet" clip-path="url(#logo-clip)" xlink:href="${l.src}"/>`);
 }
 if(frame){const title=safe(String(f.text||'ESCANÉAME').slice(0,42)),color=hex(f.color),textC=hex(f.textColor);const fontsize=Math.min(52,Math.max(26,1080/Math.max(7,title.length)));
   if(f.type==='label'){lines.push(`<rect y="1040" width="1000" height="140" fill="${color}"/><text x="500" y="1124" text-anchor="middle" dominant-baseline="middle" font-family="Arial,Helvetica,sans-serif" font-size="${fontsize}" font-weight="700" letter-spacing="3" fill="${textC}">${title}</text>`);}
   if(f.type==='card'){lines.push(`<rect x="175" y="1050" width="650" height="98" rx="49" fill="${color}"/><text x="500" y="1106" dominant-baseline="middle" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="${fontsize}" font-weight="700" letter-spacing="2" fill="${textC}">${title}</text>`);}
   if(f.type==='outline'){lines.push(`<rect x="13" y="13" width="974" height="1154" rx="22" stroke="${color}" stroke-width="14" fill="none"/><text x="500" y="1115" dominant-baseline="middle" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="${fontsize}" font-weight="700" fill="${textC}">${title}</text>`);}
 }
 lines.push('</svg>');return lines.join('');
}
function updatePreview(){const ticket=++renderTicket;let svg,payload,qr;try{payload=payloadFor(state);qr=window.AuricQREngine.create(payload,state.design.ecc);svg=qrSVG(state,payload,qr);}catch(err){previewSVG='';lastPayload='';lastQr=null;$('#qr-preview').classList.add('hidden');$('#preview-empty').classList.remove('hidden');$('#preview-empty').textContent=err.message;$('#qr-status').textContent='Contenido incompleto';$('#qr-warning').textContent=err.message;$('#stat-modules').textContent='—';$('#stat-version').textContent='—';return;}
 previewSVG=svg;lastPayload=payload;lastQr=qr;verified=false;$('#qr-preview').classList.remove('hidden');$('#preview-empty').classList.add('hidden');
 if(previewURL)URL.revokeObjectURL(previewURL);previewURL=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml'}));$('#qr-preview').src=previewURL;
 $('#preview-type-chip').textContent=typeLabels[state.type];$('#stat-modules').textContent=qr.getModuleCount()+' × '+qr.getModuleCount();$('#stat-version').textContent='Versión '+qr.typeNumber;$('#stat-ecc').textContent='ECC '+state.design.ecc;
 const risk=[];if(state.design.margin<4)risk.push('Margen inferior a 4 módulos');if(state.logo.src&&state.logo.size>23)risk.push('Logotipo muy grande');if(state.logo.src&&state.design.ecc!=='H')risk.push('Conviene corrección H con logotipo');if(state.design.transparent)risk.push('Requiere un fondo claro al imprimirse');
 const parseRGB=h=>[1,3,5].map(i=>parseInt(hex(h).slice(i,i+2),16)/255);
 const luminance=h=>parseRGB(h).map(v=>v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4)).reduce((s,v,i)=>s+v*[.2126,.7152,.0722][i],0);
 if(!state.design.transparent){const a=luminance(state.design.bg),b=luminance(state.design.fg),c=(Math.max(a,b)+.05)/(Math.min(a,b)+.05);if(c<3.5)risk.push('Contraste bajo entre módulos y fondo');if(state.design.colorMode!=='solid'){const x=luminance(state.design.fg2);if((Math.max(a,x)+.05)/(Math.min(a,x)+.05)<3.5)risk.push('Contraste insuficiente en el degradado');}}
 $('#qr-status').textContent=risk.length?'Revisa la legibilidad':'Estructura QR generada';$('#qr-warning').textContent=risk.length?risk.join(' · '):'Listo para exportar. Comprueba el escaneo con una cámara.';$('.meta-icon').classList.toggle('warning',!!risk.length);
 if(!risk.length&&typeof window.BarcodeDetector==='function'){
   setTimeout(async()=>{if(ticket!==renderTicket)return;try{const bitmap=await createCanvasFromSVG(svg,640,640,state.design.transparent);const reader=new BarcodeDetector({formats:['qr_code']});const result=await reader.detect(bitmap);if(ticket!==renderTicket)return;if(result.some(x=>x.rawValue===payload)){verified=true;$('#qr-status').textContent='Escaneo comprobado localmente';$('#qr-warning').textContent='El lector del navegador reconoce el contenido exacto. Prueba también en el dispositivo final.';}else{$('#qr-status').textContent='Revisa la legibilidad';$('#qr-warning').textContent='No se pudo verificar con el lector local. Prueba la cámara y simplifica el diseño.';$('.meta-icon').classList.add('warning');}}catch{/* El lector no está soportado; nunca afirmar que se verificó. */}},150);
 }
}
function requestRender(){projectDirty=true;saveAuto();clearTimeout(renderTimer);renderTimer=setTimeout(updatePreview,90);}
async function createCanvasFromSVG(svg,width,height,forceWhite=false){
 const blob=new Blob([svg],{type:'image/svg+xml'}),url=URL.createObjectURL(blob);
 try{
   const img=new Image();img.decoding='async';img.src=url;
   await new Promise((ok,bad)=>{img.onload=ok;img.onerror=()=>bad(Error('No se pudo procesar la vista previa SVG.'));});
   const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;const ctx=canvas.getContext('2d',{willReadFrequently:forceWhite});if(!ctx)throw Error('No se pudo crear el lienzo de imagen.');
   if(forceWhite){ctx.fillStyle='#FFFFFF';ctx.fillRect(0,0,width,height);}
   ctx.drawImage(img,0,0,width,height);return canvas;
 }finally{URL.revokeObjectURL(url);}
}
function canvasToBlob(canvas,mime,quality){return new Promise((ok,bad)=>canvas.toBlob(blob=>blob?ok(blob):bad(Error('El navegador no pudo exportar esta resolución. Prueba con un tamaño menor.')),mime,quality));}
const bytesOf=s=>new TextEncoder().encode(s);
const joined=(...parts)=>{const bytes=parts.map(p=>typeof p==='string'?bytesOf(p):p),total=bytes.reduce((s,a)=>s+a.length,0),out=new Uint8Array(total);let p=0;for(const a of bytes){out.set(a,p);p+=a.length;}return out;};
async function makePdf(svg,pxWidth,pxHeight,mmWidth){
 // Un PDF real con imagen RGB sin pérdida, comprimida en Deflate. No se usa servidor.
 if(typeof CompressionStream!=='function')throw Error('Esta versión del navegador no soporta la exportación PDF sin conexión.');
 const canvas=await createCanvasFromSVG(svg,pxWidth,pxHeight,true),ctx=canvas.getContext('2d',{willReadFrequently:true}),raw=ctx.getImageData(0,0,pxWidth,pxHeight).data;
 const rgb=new Uint8Array(pxWidth*pxHeight*3);for(let p=0,q=0;p<raw.length;p+=4){rgb[q++]=raw[p];rgb[q++]=raw[p+1];rgb[q++]=raw[p+2];}
 const stream=new Blob([rgb]).stream().pipeThrough(new CompressionStream('deflate'));const compressed=new Uint8Array(await new Response(stream).arrayBuffer());
 const wpt=+((mmWidth/25.4)*72).toFixed(3),hpt=+((wpt*pxHeight/pxWidth)).toFixed(3);
 const objects=[
 '<< /Type /Catalog /Pages 2 0 R >>',
 '<< /Type /Pages /Count 1 /Kids [3 0 R] >>',
 `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${wpt} ${hpt}] /Resources << /XObject << /Im0 5 0 R >> >> /Contents 4 0 R >>`,
 `<< /Length ${bytesOf(`q ${wpt} 0 0 ${hpt} 0 0 cm /Im0 Do Q\n`).length} >>\nstream\nq ${wpt} 0 0 ${hpt} 0 0 cm /Im0 Do Q\nendstream`,
 `<< /Type /XObject /Subtype /Image /Width ${pxWidth} /Height ${pxHeight} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode /Length ${compressed.length} >>\nstream\n`
 ];
 let parts=[bytesOf('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n')],offset=parts[0].length,positions=[0];
 for(let i=0;i<objects.length;i++){
   positions.push(offset);let head=bytesOf(`${i+1} 0 obj\n${objects[i]}`);parts.push(head);offset+=head.length;
   if(i===4){parts.push(compressed);offset+=compressed.length;}
   let tail=bytesOf('\nendobj\n');parts.push(tail);offset+=tail.length;
 }
 const xrefOffset=offset;const xref=`xref\n0 ${positions.length}\n0000000000 65535 f \n${positions.slice(1).map(p=>String(p).padStart(10,'0')+' 00000 n \n').join('')}trailer\n<< /Size ${positions.length} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;
 parts.push(bytesOf(xref));return new Blob(parts,{type:'application/pdf'});
}
async function generateExport(s,payload,format,width){
 const qr=window.AuricQREngine.create(payload,s.design.ecc),svg=qrSVG(s,payload,qr),height=Math.round(width*(s.frame.type==='none'?1000:1180)/1000);
 if(format==='svg'){
   const sized=svg.replace('viewBox="0 0 1000','width="'+width+'" height="'+height+'" viewBox="0 0 1000').replace(/ width="1000" height="(1000|1180)"(?=>)/,'');
   return new Blob([sized],{type:'image/svg+xml'});
 }
 if(format==='pdf'){const pdfWidth=Math.max(width,1200),pdfHeight=Math.round(pdfWidth*height/width);return makePdf(svg,pdfWidth,pdfHeight,limit(s.export.pdfMm,20,1000,100));}
 const mime={png:'image/png',jpeg:'image/jpeg',webp:'image/webp'}[format];if(!mime)throw Error('Formato desconocido.');
 const canvas=await createCanvasFromSVG(svg,width,height,format==='jpeg');const blob=await canvasToBlob(canvas,mime,format==='png'?undefined:.97);
 if(blob.type!==mime)throw Error('Este formato no está disponible en el navegador.');return blob;
}
async function saveBlob(blob,filename,filters){
 if(window.auricDesktop&&typeof window.auricDesktop.saveFile==='function'){
   const bytes=new Uint8Array(await blob.arrayBuffer());const result=await window.auricDesktop.saveFile({filename,bytes,filters});if(result&&result.canceled)return false;if(result&&result.error)throw Error(result.error);return true;
 }
 const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),12000);return true;
}
async function doExport(){if(!lastQr){toast('Completa un contenido válido antes de exportar.',true);setTab('content');return;}
 const btn=$('#export-side'),btn2=$('#go-export');btn.disabled=btn2.disabled=true;const orig=btn.innerHTML;btn.textContent='Exportando...';btn2.textContent='Exportando...';
 try{
   const fmt=state.export.format,w=limit(state.export.width,128,8192,1024),ext=fmt==='jpeg'?'jpg':fmt,payload=payloadFor(state),blob=await generateExport(state,payload,fmt,w);
   const saved=await saveBlob(blob,cleanName(state.export.filename)+'.'+ext,[{name:ext.toUpperCase(),extensions:[ext]}]);if(saved){addHistory('export');toast('Archivo exportado: '+ext.toUpperCase()+' · '+formatNum(w)+' px');}
 }catch(e){console.error(e);toast(e.message||'No se pudo exportar.',true);}finally{btn.disabled=btn2.disabled=false;btn.innerHTML=orig;btn2.innerHTML=icon('download')+' Exportar QR';}
}
function addHistory(reason){try{const item={id:Date.now()+Math.random(),type:state.type,title:state.type==='url'?state.fields.url:(state.type==='text'?state.fields.text.slice(0,30):typeLabels[state.type]),time:Date.now(),state:clone(state)};history=history.filter(h=>JSON.stringify(h.state)!==JSON.stringify(item.state));history.unshift(item);history=history.slice(0,25);localStorage.setItem(LS_HISTORY,JSON.stringify(history));}catch(e){console.warn('La colección local está llena:',e);}}
async function saveProject(){
 const data={app:'Auric QR',version:1,createdAt:new Date().toISOString(),project:state};const name=cleanName(state.export.filename)+'.auricqr';
 try{const success=await saveBlob(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),name,[{name:'Proyecto Auric QR',extensions:['auricqr']}]);if(success){projectDirty=false;addHistory('save');toast('Proyecto guardado: '+name);}}catch(e){toast(e.message,true);}
}
async function loadProject(){
 try{
   let json;if(window.auricDesktop&&typeof window.auricDesktop.openProject==='function'){
     const result=await window.auricDesktop.openProject();if(!result||result.canceled)return;if(result.error)throw Error(result.error);json=result.text;
   }else{json=await new Promise((resolve,reject)=>{const input=document.createElement('input');input.type='file';input.accept='.auricqr,.json,application/json';input.style.display='none';document.body.appendChild(input);input.addEventListener('change',async()=>{const file=input.files&&input.files[0];input.remove();if(!file){resolve(null);return;}if(file.size>12*1024*1024){reject(Error('El proyecto supera el límite de 12 MB.'));return;}resolve(await file.text());},{once:true});input.click();});}
   if(!json)return;const data=JSON.parse(json);if(data.app!=='Auric QR'||!data.project)throw Error('Este archivo no es un proyecto válido de Auric QR.');applyState(data.project);syncControls();setView('editor');setTab('content');requestRender();projectDirty=false;toast('Proyecto cargado correctamente.');
 }catch(e){toast('No se pudo abrir: '+e.message,true);}
}
function newProject(){applyState(DEFAULT);syncControls();setView('editor');setTab('content');requestRender();projectDirty=false;toast('Nuevo proyecto creado.');}
function loadFromHistory(id){const entry=history.find(h=>String(h.id)===String(id));if(!entry)return;applyState(entry.state);syncControls();setView('editor');setTab('content');requestRender();toast('Diseño cargado en el editor.');}
function renderHistory(){const holder=$('#collection-items');if(!history.length){holder.innerHTML=`<div class="empty-collection">${icon('grid')}<h3>Tu colección está vacía</h3><p>Guarda o exporta un código desde el editor para verlo aquí.</p></div>`;return;}
 holder.innerHTML=history.map(h=>{let svg='';try{const st=stateNormalize(h.state);svg=qrSVG(st,payloadFor(st),window.AuricQREngine.create(payloadFor(st),st.design.ecc));}catch{}const uri=svg?'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg):'';
 return `<article class="collection-card"><div class="collection-thumb"><img alt="Miniatura QR" src="${uri}"/></div><div class="collection-body"><h3 title="${safe(h.title)}">${safe(h.title)}</h3><p>${safe(typeLabels[h.type]||'Código QR')} · ${new Date(h.time).toLocaleDateString('es-CL')}</p><div class="collection-buttons"><button class="secondary-btn" data-load="${h.id}">${icon('edit')} Editar</button><button class="secondary-btn" data-remove="${h.id}" title="Quitar de la colección">${icon('trash')}</button></div></div></article>`;}).join('');
}
function removeHistory(id){history=history.filter(h=>String(h.id)!==String(id));try{localStorage.setItem(LS_HISTORY,JSON.stringify(history));}catch{}renderHistory();toast('Se quitó de la colección.');}
function parseCSV(text){const rows=[];let cells=[],cell='',quoted=false;const str=String(text||'').replace(/^\uFEFF/,'');for(let i=0;i<str.length;i++){const c=str[i];if(quoted){if(c==='"'&&str[i+1]==='"'){cell+='"';i++;}else if(c==='"')quoted=false;else cell+=c;}else{if(c==='"')quoted=true;else if(c===','||c===';'){cells.push(cell);cell='';}else if(c==='\n'){cells.push(cell.replace(/\r$/,''));rows.push(cells);cells=[];cell='';}else cell+=c;}}if(cell||cells.length){cells.push(cell.replace(/\r$/,''));rows.push(cells);}return rows;}
function getBatchRows(){return String($('#batch-input').value||'').split(/\r?\n/).map((v,i)=>({text:v.trim(),name:'qr-'+String(i+1).padStart(3,'0')})).filter(x=>x.text).slice(0,200);}
let csvRecords=null;
function batchEntries(){if(csvRecords)return csvRecords.slice(0,200);return getBatchRows();}
function renderBatch(){const rows=batchEntries();$('#batch-count').textContent=rows.length;$('#batch-list').innerHTML=rows.length?rows.slice(0,12).map((r,i)=>`<div class="batch-line"><span title="${safe(r.text)}">${safe(r.text)}</span><b>${String(i+1).padStart(2,'0')}</b></div>`).join('')+(rows.length>12?`<div class="batch-line">Y ${rows.length-12} códigos más</div>`:''):'<p>Escribe tus enlaces para verlos aquí.</p>';$('#batch-msg').textContent=rows.length>200?'Máximo 200 códigos por lote.':'Se aplicará el diseño actual del editor a todos los códigos.';}
// ZIP sin compresión externa. Los PNG ya están comprimidos; los SVG quedan legibles.
const crcTable=(()=>{const a=[];for(let n=0;n<256;n++){let c=n;for(let j=0;j<8;j++)c=c&1?0xEDB88320^(c>>>1):c>>>1;a[n]=c>>>0;}return a;})();
function crc32(data){let c=-1;for(const b of data)c=crcTable[(c^b)&255]^(c>>>8);return (c^-1)>>>0;}
function word(n){const b=new Uint8Array(2);new DataView(b.buffer).setUint16(0,n,true);return b;}
function dword(n){const b=new Uint8Array(4);new DataView(b.buffer).setUint32(0,n>>>0,true);return b;}
function zipFiles(entries){const local=[],central=[];let offset=0;const date=new Date(),dosTime=(date.getHours()<<11)|(date.getMinutes()<<5)|(date.getSeconds()>>1),dosDate=((date.getFullYear()-1980)<<9)|((date.getMonth()+1)<<5)|date.getDate();
 for(const entry of entries){const name=bytesOf(entry.name),data=entry.data,crc=crc32(data),len=data.length,lh=joined(dword(0x04034B50),word(20),word(0),word(0),word(dosTime),word(dosDate),dword(crc),dword(len),dword(len),word(name.length),word(0),name,data);local.push(lh);central.push(joined(dword(0x02014B50),word(20),word(20),word(0),word(0),word(dosTime),word(dosDate),dword(crc),dword(len),dword(len),word(name.length),word(0),word(0),word(0),word(0),dword(0),dword(offset),name));offset+=lh.length;}
 const cd=joined(...central),eocd=joined(dword(0x06054B50),word(0),word(0),word(entries.length),word(entries.length),dword(cd.length),dword(offset),word(0));return new Blob([...local,cd,eocd],{type:'application/zip'});
}
async function exportBatch(){const entries=batchEntries();if(!entries.length){toast('Agrega al menos un enlace o texto.',true);return;}const size=limit($('#batch-size').value,128,4096,1024),fmt=$('#batch-format').value,btn=$('#batch-export'),old=btn.innerHTML;btn.disabled=true;
 const files=[];let skipped=0;
 try{for(let i=0;i<entries.length;i++){
   const item=entries[i];btn.textContent=`Generando ${i+1} de ${entries.length}…`;await new Promise(ok=>setTimeout(ok,0));
   try{const qr=window.AuricQREngine.create(item.text,state.design.ecc);const svg=qrSVG(state,item.text,qr);const height=Math.round(size*(state.frame.type==='none'?1000:1180)/1000);const blob=fmt==='svg'?new Blob([svg.replace('viewBox="0 0 1000','width="'+size+'" height="'+height+'" viewBox="0 0 1000').replace(/ width="1000" height="(1000|1180)"(?=>)/,'' )],{type:'image/svg+xml'}):await generateExport(state,item.text,'png',size);files.push({name:String(i+1).padStart(3,'0')+'-'+cleanName(item.name)+'.'+fmt,data:new Uint8Array(await blob.arrayBuffer())});
   }catch(e){skipped++;console.warn('QR omitido:',i+1,e);}
 }
 if(!files.length)throw Error('No se pudo generar ningún QR. Comprueba la longitud de los contenidos.');
 const report=bytesOf(`Auric QR · Lote generado localmente\nCódigos generados: ${files.length}\nOmitidos: ${skipped}\nFormato: ${fmt.toUpperCase()}\nAncho: ${size} px\nContenido codificado directamente en cada QR.\n`);
 files.push({name:'LEEME.txt',data:report});const zip=zipFiles(files);if(await saveBlob(zip,'auric-qr-lote.zip',[{name:'Archivo ZIP',extensions:['zip']}])){toast('ZIP creado: '+(files.length-1)+' códigos'+(skipped?` · ${skipped} omitidos`:'') );$('#batch-msg').textContent=`Último lote: ${files.length-1} correctos, ${skipped} omitidos.`;}
 }catch(e){toast(e.message,true);}finally{btn.disabled=false;btn.innerHTML=old;}
}
function bind(){
 $$('.nav-btn[data-view]').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.view)));
 $$('.tab').forEach(b=>b.addEventListener('click',()=>setTab(b.dataset.tab)));
 $('#qr-type').addEventListener('change',e=>{state.type=e.target.value;renderContent();requestRender();});
 $('#content-fields').addEventListener('input',e=>{const k=e.target.dataset.field;if(!k)return;state.fields[k]=e.target.type==='checkbox'?e.target.checked:e.target.value;requestRender();});
 $('#content-fields').addEventListener('change',e=>{const k=e.target.dataset.field;if(!k)return;state.fields[k]=e.target.type==='checkbox'?e.target.checked:e.target.value;requestRender();});
 const stateInput=(id,target,key,property='value',post)=>{$('#'+id).addEventListener('input',e=>{target[key]=e.target[property];if(post)post();requestRender();});};
 stateInput('color-mode',state.design,'colorMode', 'value',()=>{syncControls();});
 stateInput('gradient-angle',state.design,'angle','value',()=>$('#gradient-angle-label').textContent=state.design.angle+'°');
 stateInput('transparent',state.design,'transparent','checked');stateInput('eye-shape',state.design,'eyeShape');stateInput('eye-inner',state.design,'eyeInner');stateInput('ecc',state.design,'ecc');stateInput('margin',state.design,'margin','value',()=>$('#margin-label').textContent=state.design.margin+' módulos');
 stateInput('logo-size',state.logo,'size','value',()=>$('#logo-size-label').textContent=state.logo.size+' %');stateInput('logo-padding',state.logo,'padding','value',()=>$('#logo-padding-label').textContent=state.logo.padding+' %');stateInput('logo-shape',state.logo,'shape');
 stateInput('frame-text',state.frame,'text');
 stateInput('export-size',state.export,'width','value',()=>{state.export.width=limit(state.export.width,128,8192,1024);const w=state.export.width;$('#export-width-label').textContent=formatNum(w)+' px';$('#export-preset').value=[256,512,1024,2048,4096,8192].includes(Number(w))?String(w):'';updateMeasures();});
 $('#export-preset').addEventListener('change',e=>{if(!e.target.value)return;state.export.width=Number(e.target.value);$('#export-size').value=state.export.width;$('#export-width-label').textContent=formatNum(state.export.width)+' px';updateMeasures();requestRender();});
 stateInput('pdf-mm',state.export,'pdfMm');stateInput('filename',state.export,'filename');
 function colorBind(colorId,textId,obj,key){const color=$('#'+colorId),txt=$('#'+textId);color.addEventListener('input',()=>{obj[key]=color.value;txt.value=color.value.toUpperCase();requestRender();});txt.addEventListener('change',()=>{if(/^#[0-9a-f]{6}$/i.test(txt.value)){obj[key]=txt.value;color.value=txt.value;requestRender();}else{txt.value=hex(obj[key]).toUpperCase();toast('Color no válido. Usa #RRGGBB.',true);}});}
 for(const [a,b,obj,key] of [['color-fg','text-fg',state.design,'fg'],['color-fg2','text-fg2',state.design,'fg2'],['color-bg','text-bg',state.design,'bg'],['eye-color','text-eye',state.design,'eyeColor'],['eye-inner-color','text-eye-inner',state.design,'eyeInnerColor'],['frame-color','text-frame',state.frame,'color'],['frame-text-color','text-frame-text',state.frame,'textColor']])colorBind(a,b,obj,key);
 $$('.shape').forEach(b=>b.addEventListener('click',()=>{state.design.dot=b.dataset.dot;$$('.shape').forEach(x=>x.classList.toggle('selected',x===b));requestRender();}));
 $$('.frame-choice').forEach(b=>b.addEventListener('click',()=>{state.frame.type=b.dataset.frame;$$('.frame-choice').forEach(x=>x.classList.toggle('active',x===b));updateMeasures();requestRender();}));
 $$('.format-button').forEach(b=>b.addEventListener('click',()=>{state.export.format=b.dataset.format;$$('.format-button').forEach(x=>x.classList.toggle('active',x===b));$('#pdf-options').classList.toggle('hidden',state.export.format!=='pdf');updateMeasures();requestRender();}));
 $('#eyes-match').addEventListener('click',()=>{state.design.eyeColor=state.design.fg;state.design.eyeInnerColor=state.design.fg;$('#eye-color').value=state.design.fg;$('#eye-inner-color').value=state.design.fg;$('#text-eye').value=state.design.fg.toUpperCase();$('#text-eye-inner').value=state.design.fg.toUpperCase();requestRender();toast('Colores de esquinas sincronizados.');});
 const upload=$('#logo-drop'),file=$('#logo-file');upload.addEventListener('click',()=>file.click());upload.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();file.click();}});
 upload.addEventListener('dragover',e=>{e.preventDefault();upload.classList.add('dragover');});upload.addEventListener('dragleave',()=>upload.classList.remove('dragover'));upload.addEventListener('drop',e=>{e.preventDefault();upload.classList.remove('dragover');if(e.dataTransfer.files.length)loadLogo(e.dataTransfer.files[0]);});file.addEventListener('change',e=>{if(e.target.files.length)loadLogo(e.target.files[0]);e.target.value='';});
 $('#remove-logo').addEventListener('click',()=>{state.logo.src='';state.logo.name='';$('#logo-current').classList.add('hidden');requestRender();toast('Logotipo eliminado.');});
 $('#go-export').addEventListener('click',()=>{setTab('export');});$('#export-side').addEventListener('click',doExport);$('#new-project').addEventListener('click',newProject);$('#collection-new').addEventListener('click',newProject);$('#open-project').addEventListener('click',loadProject);$('#save-project').addEventListener('click',saveProject);
 $('#reset-style').addEventListener('click',()=>{Object.assign(state.design,clone(DEFAULT.design));Object.assign(state.logo,clone(DEFAULT.logo));Object.assign(state.frame,clone(DEFAULT.frame));syncControls();requestRender();toast('Apariencia restablecida.');});
 $('#copy-payload').addEventListener('click',async()=>{if(!lastPayload){toast('Primero completa el contenido.',true);return;}try{await navigator.clipboard.writeText(lastPayload);toast('Contenido del QR copiado.');}catch{const box=document.createElement('textarea');box.value=lastPayload;document.body.appendChild(box);box.select();const ok=document.execCommand('copy');box.remove();toast(ok?'Contenido copiado.':'No se pudo copiar.',!ok);}});
 $('#collection-items').addEventListener('click',e=>{const b=e.target.closest('button');if(b?.dataset.load)loadFromHistory(b.dataset.load);if(b?.dataset.remove)removeHistory(b.dataset.remove);});
 $('#batch-input').addEventListener('input',()=>{csvRecords=null;renderBatch();});$('#batch-example').addEventListener('click',()=>{$('#batch-input').value='https://example.com\nhttps://wikipedia.org\n¡Creado con Auric QR!';csvRecords=null;renderBatch();});
 $('#batch-import').addEventListener('click',()=>$('#batch-file').click());$('#batch-file').addEventListener('change',async e=>{const file=e.target.files[0];e.target.value='';if(!file)return;if(file.size>1024*1024){toast('El CSV supera el límite de 1 MB.',true);return;}try{const rows=parseCSV(await file.text());if(!rows.length)throw Error('El archivo CSV está vacío.');const heads=rows[0].map(s=>s.trim().toLowerCase()),cIdx=heads.findIndex(s=>['contenido','content','url','texto','text','link'].includes(s)),nIdx=heads.findIndex(s=>['nombre','name','archivo','filename'].includes(s));const hasHead=cIdx!==-1;csvRecords=rows.slice(hasHead?1:0).map((cols,i)=>({text:String(cols[hasHead?cIdx:0]||'').trim(),name:String(cols[hasHead&&nIdx>=0?nIdx:1]||`qr-${String(i+1).padStart(3,'0')}`).trim()})).filter(r=>r.text).slice(0,200);$('#batch-input').value=csvRecords.map(r=>r.text).join('\n');renderBatch();toast('CSV importado: '+csvRecords.length+' elementos.');}catch(err){toast(err.message,true);}});
 $('#batch-export').addEventListener('click',exportBatch);
 window.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();saveProject();}if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='o'){e.preventDefault();loadProject();}if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='n'){e.preventDefault();newProject();}});
}
function updateMeasures(){const sz=fileInfo();$('#measure-width').textContent=formatNum(sz.width)+' px';$('#measure-height').textContent=formatNum(sz.height)+' px';$('#measure-format').textContent=state.export.format.toUpperCase();}
async function loadLogo(file){try{
 if(file.size>8*1024*1024)throw Error('El logotipo supera los 8 MB.');if(!['image/png','image/jpeg','image/webp','image/svg+xml'].includes(file.type))throw Error('Selecciona PNG, JPG, WebP o SVG.');
 const uri=await new Promise((ok,bad)=>{const fr=new FileReader();fr.onload=()=>ok(fr.result);fr.onerror=()=>bad(Error('No se pudo leer la imagen.'));fr.readAsDataURL(file);});
 // Normalizamos a PNG: evita scripts o contenido activo procedente de SVG externos.
 const img=new Image();img.src=uri;await new Promise((ok,bad)=>{img.onload=ok;img.onerror=()=>bad(Error('Imagen dañada o no admitida.'));});
 const canvas=document.createElement('canvas');const ratio=Math.min(1,640/Math.max(img.naturalWidth,img.naturalHeight));canvas.width=Math.max(1,Math.round(img.naturalWidth*ratio));canvas.height=Math.max(1,Math.round(img.naturalHeight*ratio));canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);
 state.logo.src=canvas.toDataURL('image/png');state.logo.name=file.name;$('#logo-current').classList.remove('hidden');$('#logo-thumbnail').src=state.logo.src;$('#logo-name').textContent=file.name;requestRender();toast('Logotipo incorporado localmente.');
 }catch(e){toast(e.message,true);}}
function init(){syncControls();bind();setTab('content');updatePreview();renderBatch();}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
