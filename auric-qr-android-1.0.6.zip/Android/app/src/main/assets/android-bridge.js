/* Puente exclusivamente Android; escritorio conserva su adaptador Electron. */
(()=>{'use strict';if(!window.AuricAndroid)return;
let next=1;const pending=new Map();
window.__auricAndroidResolve=(id,result)=>{const cb=pending.get(id);if(cb){pending.delete(id);cb(result);}};
function request(fn,...args){return new Promise(resolve=>{const id=next++;pending.set(id,resolve);try{fn.call(window.AuricAndroid,String(id),...args)}catch(e){pending.delete(id);resolve({error:String(e)})}})}
const base64Bytes=bytes=>{let s='';const n=8192;for(let i=0;i<bytes.length;i+=n){s+=String.fromCharCode.apply(null,bytes.subarray(i,i+n))}return btoa(s)};
window.auricDesktop={saveFile:async req=>{const arr=new Uint8Array(req.bytes);if(arr.length>30*1024*1024)return{error:'El archivo supera 30 MB. Exporta una resolución menor en Android.'};const name=String(req.filename||'auric-qr.png').replace(/[\/]/g,'_').slice(0,110);return request(window.AuricAndroid.saveFile,name,base64Bytes(arr));},openProject:()=>request(window.AuricAndroid.openProject)};
})();
