# Auric QR para Android — 1.0.6

Proyecto Android nativo en Java con WebViewAssetLoader y escáner ZXing integrado. El generador y el editor son idénticos a los de Windows, empaquetados como recursos de la app. No requiere servidor ni cuenta.

## Compilación
- Android Studio, JDK 17, Android SDK Platform 35 y Gradle 8.11.1.
- Abrir esta carpeta `Android/` en Android Studio; dejar que sincronice dependencias y ejecutar **Build > Build APK(s)**.
- APK de prueba en `app/build/outputs/apk/debug/app-debug.apk` (firmado automáticamente con clave de desarrollo).
- Para una versión final publica de verdad, generar y conservar una **clave privada de firma de producción** en lugar de utilizar la firma de debug. No publicar una clave privada en GitHub.
- El workflow en la raíz del proyecto (`.github/workflows/build-android.yml`) permite generar un APK de prueba con GitHub Actions. Cada ejecución usa la firma debug; no debe distribuirse como versión final sin configurar una firma de publicación estable.

## Actualización del editor compartido
El directorio `app/src/main/assets` contiene una copia del editor de `../Source/app/src`; cualquier cambio de interfaz debe sincronizarse antes de compilar.

## Escaneo
Cámara: ZXing Android Embedded. Imagen: ZXing Core decodifica de manera local. Historial: almacenamiento local de WebView. Los enlaces nunca se abren sin confirmación.
